package com.cts.repository;
import org.springframework.data.repository.CrudRepository;

import com.cts.model.Ipo;
public interface IpoRepository extends CrudRepository<Ipo, Long> {

}






//package com.vp.unittest;
//
//import static org.junit.Assert.assertEquals;
//
//import org.junit.After;
//import org.junit.AfterClass;
//import org.junit.Before;
//import org.junit.BeforeClass;
//import org.junit.Test;
//
//import com.vp.logic.JunitLogic;
//
//public class JunitTest {
//	@BeforeClass
//	static public void beforeClass() {
//		System.out.println("beforeClass");
//	}
//	
//	@Before
//	public void beforeTest() {
//		System.out.println("Before");
//	}
//	
//	@Test
//	public void testAdd() {
//		System.out.println("in test testAdd");
//		assertEquals(300, JunitLogic.add(100, 200));
//	}
//	
//	@Test
//	public void testCube() {
//		assertEquals(8, JunitLogic.cube(2));
//	}
//	
//	@After
//	public void afterTest() {
//		System.out.println("afterTest");
//	}
//	
//	@AfterClass
//	static public void afterClass(){
//		System.out.println("afterClass ... ");
//	}
//}