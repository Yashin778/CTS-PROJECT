import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UlandingComponent } from './ulanding.component';

describe('UlandingComponent', () => {
  let component: UlandingComponent;
  let fixture: ComponentFixture<UlandingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UlandingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UlandingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
