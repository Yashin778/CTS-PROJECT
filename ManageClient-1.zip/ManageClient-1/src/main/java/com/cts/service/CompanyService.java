package com.cts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.model.Company;
import com.cts.repository.CompanyRepository;

@Service
@Transactional
public class CompanyService {
    
	@Autowired
	CompanyRepository companyRepository;
	
	public List<Company> getAllCompany(){
		return (List<Company>) companyRepository.findAll();
	}
	
	public void saveCompany(Company company) {
		companyRepository.save(company);
	}
	public boolean updateCompany(Company company) {
		return companyRepository.save(company) != null;
	}
	public void deleteCompany(Long id) {
		companyRepository.deleteById(id);
	}
	
}