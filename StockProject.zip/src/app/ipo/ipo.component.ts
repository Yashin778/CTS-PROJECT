import { Component, OnInit } from '@angular/core';
import { IpoModel } from 'src/entity/IpoModel';
import { IpoService } from '../service/ipo.service';

@Component({
  selector: 'app-ipo',
  templateUrl: './ipo.component.html',
  styleUrls: ['./ipo.component.css']
})
export class IpoComponent implements OnInit {
  ipo:IpoModel[];
  constructor(private service:IpoService) { }

  ngOnInit(): void {
    this.service.getAllIpo().subscribe(data =>{
      this.ipo=data.body;
      
      });
  }

}
