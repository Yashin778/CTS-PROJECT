package com.cts.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.model.Stock;
import com.cts.repository.StockRepository;

@Service
@Transactional
public class StockService {
	@Autowired
	StockRepository stockRepository;
	
	public List <Stock> getAllStock(){
		return (List <Stock>) stockRepository.findAll();
	}
	
	public void saveStock(Stock stock) {
		stockRepository.save(stock);
	}
	
	
	
}
