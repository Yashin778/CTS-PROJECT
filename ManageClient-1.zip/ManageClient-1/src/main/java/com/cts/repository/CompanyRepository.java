package com.cts.repository;
import org.springframework.data.repository.CrudRepository;

import com.cts.model.Company;
public interface CompanyRepository extends CrudRepository<Company, Long>{

}
