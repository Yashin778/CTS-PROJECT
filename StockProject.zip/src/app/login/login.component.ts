import { Component, OnInit } from '@angular/core';
import { UserModel } from 'src/entity/UserModel';
import { UsersService } from '../service/users.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  users:UserModel[];
  myForm: FormGroup;
  constructor(private service:UsersService,private route:Router) { }

  ngOnInit(): void {
    this.service.getAllUser().subscribe(data => {
      this.users = data.body;
      
});

 this.myForm=new FormGroup({
  // uid:new FormControl(''),
  uname:new FormControl('',Validators.required),
  password:new FormControl('',Validators.required),
  

 });
  }
  onSubmit(myform: FormGroup) {
    // console.log(form.value.pass);
    // console.log(this.user[0].password);
    var k = 0;
    for (var i = 0; i < this.users.length; i++) {
      if (this.users[i].uname == myform.value.uname && this.users[i].password == myform.value.password) {
        k = 2;
        if (this.users[i].usertype == "admin") {

          this.route.navigate(['/admin'])

          alert("verified");
          break;
        }
        else {
          this.route.navigate(["/ulanding"])
          alert("Hey User");
          break;
        }
      }

    }

    if (k == 0) {
      alert("Wrong Credentials")
    }

  }
}
   
