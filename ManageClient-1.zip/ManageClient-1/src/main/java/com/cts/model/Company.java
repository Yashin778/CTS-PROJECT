package com.cts.model;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "company1")

public class Company {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
	private String company_name;
    private String turnover;
    private String ceo;
    private String board_of_directors;
    private String listed_stock_exchanges;
    private String sector;
    private String brief_writeup;
    private int company_stock_code;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getCompany_name() {
		return company_name;
	}
	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}
	public String getTurnover() {
		return turnover;
	}
	public void setTurnover(String turnover) {
		this.turnover = turnover;
	}
	public String getCeo() {
		return ceo;
	}
	public void setCeo(String ceo) {
		this.ceo = ceo;
	}
	public String getBoard_of_directors() {
		return board_of_directors;
	}
	public void setBoard_of_directors(String board_of_directors) {
		this.board_of_directors = board_of_directors;
	}
	public String getListed_stock_exchanges() {
		return listed_stock_exchanges;
	}
	public void setListed_stock_exchanges(String listed_stock_exchanges) {
		this.listed_stock_exchanges = listed_stock_exchanges;
	}
	public String getSector() {
		return sector;
	}
	public void setSector(String sector) {
		this.sector = sector;
	}
	public String getBrief_writeup() {
		return brief_writeup;
	}
	public void setBrief_writeup(String brief_writeup) {
		this.brief_writeup = brief_writeup;
	}
	public int getCompany_stock_code() {
		return company_stock_code;
	}
	public void setCompany_stock_code(int company_stock_code) {
		this.company_stock_code = company_stock_code;
	}
	
}
