import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { StockService } from '../service/stock.service';
import { StockModel } from 'src/entity/StockModel';

@Component({
  selector: 'app-newextend',
  templateUrl: './newextend.component.html',
  styleUrls: ['./newextend.component.css']
})
export class NewextendComponent implements OnInit {
  myForm: FormGroup;
  constructor(private service: StockService) { }

  ngOnInit(): void {
    this.myForm = new FormGroup({
      name: new FormControl(""),
      brief: new FormControl(""),
      address: new FormControl(""),
      remarks: new FormControl("")
    });
  }
  onSubmit(form: FormGroup) {

    let exch: StockModel = {

      stock_exchange: form.value.name,
      brief: form.value.brief,
      contact_address: form.value.address,
      remarks: form.value.remarks

    }

    this.service.saveStock(exch).subscribe(data => {
      console.log(data)
    })

  }
  notify() {
    alert("Data is Saved");
  }



}
