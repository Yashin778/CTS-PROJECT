import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { StockModel } from 'src/entity/StockModel';
type EntityResponseType = HttpResponse<StockModel[]>;
@Injectable({
  providedIn: 'root'
})
export class StockService {

  constructor(private http:HttpClient) { }
  getAllStock():Observable<EntityResponseType>{
    //return this.http.get<StudentModel[]>("http://localhost:8084/students", {observe: 'response'});
    return this.http.get<StockModel[]>("http://localhost:8095/stocks", {observe: 'response'});
}


saveStock(stockModel:StockModel){
   return this.http.post<StockModel>("http://localhost:8095/stock", stockModel, {observe: 'response'});
}


}
