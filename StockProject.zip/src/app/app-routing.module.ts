import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdminlandingComponent } from './adminlanding/adminlanding.component';
import { ImportComponent } from './import/import.component';
import { UlandingComponent } from './ulanding/ulanding.component';
import { IpoComponent } from './ipo/ipo.component';
import { CompareComponent } from './compare/compare.component';
import { SectorComponent } from './sector/sector.component';
import { CompanyComponent } from './company/company.component';
import { ExtendComponent } from './extend/extend.component';
import { SignupComponent } from './signup/signup.component';
import { LoginComponent } from './login/login.component';
import { CreatecompanyComponent } from './createcompany/createcompany.component';
import { NewextendComponent } from './newextend/newextend.component';
import { UpdateipoComponent } from './updateipo/updateipo.component';
import { NewipoComponent } from './newipo/newipo.component';
import { UploadComponent } from './upload/upload.component';
const routes: Routes = [
  {path:'',component:LoginComponent},
        {path:'admin',component:AdminlandingComponent},
        {path:'sign',component:SignupComponent},
  {path:'import',component:ImportComponent},
{path:'ulanding',component:UlandingComponent},
{path:'ipo',component:IpoComponent},
{path:'ulanding/ipo',component:IpoComponent},
{path:'compareit',component:CompareComponent},
// {path:'ulanding/compareit',component:IpoComponent},
// {path:'ulanding/sectors',component:SectorComponent},
{path:'sectors',component:CompareComponent},
{path:'company',component:CompanyComponent},
{path:'exchange',component:ExtendComponent}, 
  
  {path:'signup',component:SignupComponent},
  {path:'createnew',component:CreatecompanyComponent},
  {path:'new_exchange',component:NewextendComponent},
  {path:'update1',component:UpdateipoComponent},
  {path:'createipo',component:NewipoComponent},
  {path:'update',component:UpdateipoComponent},
  {path:'viewexcel',component:UploadComponent},
  {path:'logout',component:LoginComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
