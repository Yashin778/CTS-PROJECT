import { Component, OnInit } from '@angular/core';
import { ImportModel } from 'src/entity/ImportModel';
import { ImportService } from '../service/import.service';
import { Router } from '@angular/router';
import { ExcelModel } from 'src/entity/ExcelModel';

@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.css']
})
export class UploadComponent implements OnInit {
  excelDetails: ImportModel[];
  constructor(private service:ImportService,private router: Router) { }
  excelSumary1:ExcelModel;
  ss: any;
  ngOnInit(): void {
    this.service.getAllStockData().subscribe(data => {
      this.excelDetails = data.body;
      console.log(data.body) 
  });


    this.service.getAllDetails1().subscribe(data => {
      this.excelSumary1 = data.body;
      console.log(data.body);
    

    });


  }

}
