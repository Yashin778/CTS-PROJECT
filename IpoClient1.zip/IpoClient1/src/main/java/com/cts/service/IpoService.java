package com.cts.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.model.Ipo;
import com.cts.repository.IpoRepository;

@Service
@Transactional
public class IpoService {

	@Autowired
	IpoRepository ipoRepository;
	
	public List<Ipo> getAllIpo(){
		return (List<Ipo>) ipoRepository.findAll();
	}
	
	public void saveIpo(Ipo ipo) {
		ipoRepository.save(ipo);
	}
	
	
}
