import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse, HttpRequest, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ImportModel } from 'src/entity/ImportModel';
import { ExcelModel } from 'src/entity/ExcelModel';
type EntityResponseType = HttpResponse<ImportModel[]>;
type EntityResponseType1 = HttpResponse<ExcelModel>;
@Injectable({
  providedIn: 'root'
})
export class ImportService {

  constructor(private http:HttpClient) { }
  pushFileToStorage(file: File): Observable<HttpEvent<{}>> {
    const formdata: FormData = new FormData();
    formdata.append('file', file);

    const req = new HttpRequest('POST', 'http://localhost:8098/import', formdata, {
      reportProgress: true,
      responseType: 'text'
    }

    );

    return this.http.request(req);
  }

  getAllStockData():Observable<EntityResponseType>{
    
      return this.http.get<ImportModel[]>("http://localhost:8098/stockData", {observe: 'response'});
  }
  getAllDetails1():Observable<EntityResponseType1>{
    return this.http.get<ExcelModel>("http://localhost:8098/summary", {observe: 'response'});
  }

}