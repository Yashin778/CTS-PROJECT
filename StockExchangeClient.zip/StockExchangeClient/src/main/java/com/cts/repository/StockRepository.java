package com.cts.repository;

import org.springframework.data.repository.CrudRepository;

import com.cts.model.Stock;

public interface StockRepository extends CrudRepository<Stock, Long>{

}