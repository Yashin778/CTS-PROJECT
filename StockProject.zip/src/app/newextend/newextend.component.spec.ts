import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewextendComponent } from './newextend.component';

describe('NewextendComponent', () => {
  let component: NewextendComponent;
  let fixture: ComponentFixture<NewextendComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewextendComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewextendComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
