import { Component, OnInit } from '@angular/core';
import { StockModel } from 'src/entity/StockModel';
import { StockService } from '../service/stock.service';

@Component({
  selector: 'app-extend',
  templateUrl: './extend.component.html',
  styleUrls: ['./extend.component.css']
})
export class ExtendComponent implements OnInit {
  exchange:StockModel[]
  constructor(private service: StockService) { }

  ngOnInit(): void {
    this.service.getAllStock().subscribe(data => {
      this.exchange = data.body;
      console.log(">>>>>>>>>> users :: " + this.exchange);


    });

  }
  refresh(): void {
    window.location.reload();
  }


}
