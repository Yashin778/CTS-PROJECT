import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminlanding',
  templateUrl: './adminlanding.component.html',
  styleUrls: ['./adminlanding.component.css']
})
export class AdminlandingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
