import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { UserModel } from 'src/entity/UserModel';
import { UsersService } from '../service/users.service';
@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
 myForm :FormGroup;
 user1:UserModel[];
  constructor(private service: UsersService) { }

  ngOnInit(): void {

    this.myForm = new FormGroup({
      uname: new FormControl(''),
      password: new FormControl(''),
     // usertype: new FormControl(''),
      email: new FormControl(''),
      pnum: new FormControl(''),
    });
  }
  

  onSubmit(myForm: FormGroup) {

    console.log('Valid?', myForm.valid); // true or false

    console.log(myForm.value.too);
    console.log(myForm.value.ceoname);


    let user1: UserModel = {

      uname: myForm.value.uname,
      password: myForm.value.password,
      usertype: 'user',
      email: myForm.value.email,
      pnum: myForm.value.pnum
     
    }

    console.log('Saving data')
    this.service.saveUser(user1).subscribe(data => {
      console.log(data);
    });
alert("data submitted");
  }


}
