import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {RouterModule,Routes} from '@angular/router'; 
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { AdminlandingComponent } from './adminlanding/adminlanding.component';
import { UlandingComponent } from './ulanding/ulanding.component';
import { CompareComponent } from './compare/compare.component';
import { UserComponent } from './user/user.component';
import { ImportComponent } from './import/import.component';
import { IpoComponent } from './ipo/ipo.component';
import { SignupComponent } from './signup/signup.component';
import { CompanyComponent } from './company/company.component';
import { ExtendComponent } from './extend/extend.component';
import { SectorComponent } from './sector/sector.component';
import { LoginComponent } from './login/login.component';
import { ReactiveFormsModule } from '@angular/forms';
import { UsersService } from './service/users.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { CreatecompanyComponent } from './createcompany/createcompany.component';
import { NewextendComponent } from './newextend/newextend.component';
import { UpdateipoComponent } from './updateipo/updateipo.component';
import { NewipoComponent } from './newipo/newipo.component';
import { UploadComponent } from './upload/upload.component';
import { ChartsModule } from 'ng2-charts';


@NgModule({
  declarations: [
    AppComponent,
    AdminlandingComponent,
    UlandingComponent,
    CompareComponent,
    UserComponent,
    ImportComponent,
    IpoComponent,
    SignupComponent,
    CompanyComponent,
    ExtendComponent,
    SectorComponent,
    LoginComponent,
    CreatecompanyComponent,
    NewextendComponent,
    UpdateipoComponent,
    NewipoComponent,
    UploadComponent,
    
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    ChartsModule
    

      


    
  
],
  
  providers: [ UsersService],
  bootstrap: [AppComponent]
})
export class AppModule { }
