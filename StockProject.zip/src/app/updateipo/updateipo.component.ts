import { Component, OnInit } from '@angular/core';
import { IpoService } from '../service/ipo.service';
import { IpoModel } from 'src/entity/IpoModel';

@Component({
  selector: 'app-updateipo',
  templateUrl: './updateipo.component.html',
  styleUrls: ['./updateipo.component.css']
})
export class UpdateipoComponent implements OnInit {
  ipo:IpoModel[];
  constructor(private service:IpoService) { }

  ngOnInit(): void {
    this.service.getAllIpo().subscribe(data =>{
      this.ipo=data.body;
      
      });

  }

}
