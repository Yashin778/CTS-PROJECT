export interface ImportModel{
    sid?:number;
    companyCode :string;
    stockExchange:string;
    pricePerShare:string;
    date:string;
    time:string;
    
}
