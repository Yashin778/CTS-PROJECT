export interface UserModel{
    uid?:number;
    uname:string;
    password:string;
    usertype?:string;
    pnum:string;
    email:string;
    confirmation?:string; 
}

