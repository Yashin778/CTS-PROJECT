export interface CompanyModel{
    id?:number;
    company_name :string;
    turnover:string;
    ceo:string;
    board_of_directors:string;
    listed_stock_exchanges:string;
    sector:string; 
    brief_writeup:string;
    company_stock_code:number;
}
