import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ulanding',
  templateUrl: './ulanding.component.html',
  styleUrls: ['./ulanding.component.css']
})
export class UlandingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
