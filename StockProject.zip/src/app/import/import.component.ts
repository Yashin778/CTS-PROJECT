import { Component, OnInit } from '@angular/core';
import { ImportService } from '../service/import.service';
import { Router } from '@angular/router';
import { HttpClient, HttpResponse, HttpEventType } from '@angular/common/http';

@Component({
  selector: 'app-import',
  templateUrl: './import.component.html',
  styleUrls: ['./import.component.css']
})
export class ImportComponent {

  selectedFiles: FileList;
   currentFileUpload: File;
    constructor(private uploadService: ImportService , private router: Router) {}

    selectFile(event) {
      this.selectedFiles = event.target.files;
    }
    upload() {

      this.currentFileUpload = this.selectedFiles.item(0);
      this.uploadService.pushFileToStorage(this.currentFileUpload).subscribe(event => {
      if (event instanceof HttpResponse) {
          console.log('File is completely uploaded!');
          this.router.navigate(['/viewexcel']);
        }
      });

    this.selectedFiles = undefined;
  }

}