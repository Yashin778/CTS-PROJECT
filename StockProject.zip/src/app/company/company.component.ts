import { Component, OnInit } from '@angular/core';
import { CompanyModel } from 'src/entity/CompanyModel';
import { CompanyService } from '../service/company.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-company',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.css']
})
export class CompanyComponent implements OnInit {
  company: CompanyModel[];
  use: any;
  constructor(private service: CompanyService,
    private router: Router) { }
   
    delete(id): void {
      console.log(id);
      this.service.deleteCompany(id).subscribe(data =>
        this.use = data
      );
      
    }
   

  ngOnInit(): void {
    this.service.getAllCompany().subscribe(data => {
      this.company = data.body;
      console.log(">>>>>>>>>> users :: " + this.company);


    });

  }
  update(id: number) {
    this.router.navigate(['/update', id]);
  }

  // added!!
  refresh(): void {
    window.location.reload();
  }

  }





